package com.shashi.training;

public abstract class Instrument {
	public abstract void play();
}
